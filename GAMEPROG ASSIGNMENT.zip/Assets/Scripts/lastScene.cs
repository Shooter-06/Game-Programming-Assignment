using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lastScene : MonoBehaviour
{
    // int myscore;
    // private void Start()
    // {
    //     GameManager.Instance.LoadLastScene();
    //     GameManager.Instance.UpdateScore(myscore);
    // }
}
